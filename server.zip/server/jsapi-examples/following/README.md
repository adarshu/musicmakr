# Following

This app shows you which of the people you're following are online, and what they're listening to.

http://iangilman.com/rdio/following/

For information on using this example, see https://github.com/rdio/jsapi-examples#rdio-js-api-examples.
