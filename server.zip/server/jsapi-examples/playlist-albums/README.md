# Playlist Albums

Allows you to view a playlist as if it was a set of albums.

http://iangilman.com/rdio/playlist-albums/

For information on using this example, see https://github.com/rdio/jsapi-examples#rdio-js-api-examples.

# To Do (possible future additions to this example)

* Clean up code so it's a proper example
* "Now Playing" section with pause
* shared_playstate
* The ability to delete an album from a playlist
