# Basic Starter

A simple example app for the new Rdio JavaScript API. 

http://iangilman.com/rdio/basic-starter/

For information on using this example, see https://github.com/rdio/jsapi-examples#rdio-js-api-examples.
