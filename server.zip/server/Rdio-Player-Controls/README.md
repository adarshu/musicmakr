Rdio Player Controls v0.2
=========================

**Licensed under BSD License**

The idea behind this is that Rdio developers can pass in their player reference into this control and it will handle all the various basic functions (play, pause, next, skip etc), which means they can focus on their app.

![Player control screenshot](http://i.imgur.com/mEc44z7.png)

To use, simply include the JS and CSS, then create a new instance of the controls passing in the ID of the container you want it to appear in, and a reference to the Rdio player instance.

	var player = new metronomik.player("player", R.player);

**Notes**

* You'll need to be using the new Javascript API (you have to ask Rdio to be invited)
* Run it on localhost:8000 if you are not using your own app
* Icons are from [glyphlibrary 4](http://www.glyphlibrary.com/) (thanks, Lloyd)
  * Icons are SVGs compiled into the Javascript file

## Generator

Here: http://www.metronomik.com/projects/rdioplayercontrols

## Let us know!

We'd like to know who's using the control so we can show you off :)
